package com.progressivefps;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.MinecraftClient;

public class ProgressiveFPSStabilizer implements ClientModInitializer {
private static int targetFps = 60; // Default target FPS

@Override
public void onInitializeClient() {
System.out.println("[ProgressiveFPS] Mod loaded!");

// Background thread to monitor FPS
new Thread(() -> {
while (true) {
try {
Thread.sleep(1000); // every 1 sec
} catch (InterruptedException ignored) {}

MinecraftClient client = MinecraftClient.getInstance();
if (client == null) continue;

int currentFps = client.getCurrentFps();
System.out.println("[ProgressiveFPS] Current FPS: " + currentFps);

if (currentFps < targetFps) {
applyOptimizations(client);
} else {
recoverSettings(client);
}
}
}).start();
}

private void applyOptimizations(MinecraftClient client) {
// Simple optimization steps
if (client.options.getViewDistance().getValue() > 2) {
client.options.getViewDistance().setValue(2);
System.out.println("[ProgressiveFPS] Lowered render distance");
}
client.options.getCloudRenderMode().setValue(false);
}

private void recoverSettings(MinecraftClient client) {
// Simple recovery example
if (client.options.getViewDistance().getValue() < 6) {
client.options.getViewDistance().setValue(6);
System.out.println("[ProgressiveFPS] Restored render distance");
}
}
}